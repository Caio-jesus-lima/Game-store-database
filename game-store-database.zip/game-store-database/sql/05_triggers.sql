-- Fonte: Entrega final do Projeto - Sistema de Gestao de Loja de Games (novembro de 2026).
-- Transcricao organizada do PDF final; requer validacao no Microsoft SQL Server.

use Loja_Games
go
/* 1) Ao vender, atualiza o estoque e o valor total da venda.
Nao permite vender mais do que existe em estoque: nesse caso a
inclusao do item e desfeita */
create trigger tr_item_venda_insere
on Venda_Produto
after insert
as
begin
if exists (select *
from Produto p
where p.cod_produto in (select cod_produto from inserted)
and isnull(p.qtd_estoque, 0) < (select sum(i.quantidade)
from inserted i
where i.cod_produto =
p.cod_produto))
begin
print 'Estoque insuficiente. Item da venda cancelado.'
rollback transaction
return
end
update Produto
set qtd_estoque = qtd_estoque - (select sum(i.quantidade)
from inserted i
where i.cod_produto = Produto.cod_produto)
where cod_produto in (select cod_produto from inserted)
update Venda
set valorTotal = (select sum(vp.quantidade * p.preco)
from Venda_Produto vp inner join Produto p
on p.cod_produto = vp.cod_produto
where vp.cod_venda = Venda.cod_venda)
where cod_venda in (select cod_venda from inserted)
end
go
/* 2) Ao remover um item de venda (ou cancelar a venda), devolve os
produtos ao estoque e recalcula o valor total da venda */
create trigger tr_item_venda_remove
on Venda_Produto
after delete
as
begin
update Produto
set qtd_estoque = isnull(qtd_estoque, 0) + (select sum(d.quantidade)
from deleted d
where d.cod_produto =
Produto.cod_produto)
where cod_produto in (select cod_produto from deleted)
update Venda
set valorTotal = isnull((select sum(vp.quantidade * p.preco)
from Venda_Produto vp inner join Produto p
on p.cod_produto = vp.cod_produto
where vp.cod_venda = Venda.cod_venda), 0)
where cod_venda in (select cod_venda from deleted)
end
go
/* 3) Ao incluir um item em um pedido de reposicao, confere se o
fornecedor do pedido disponibiliza aquele produto e recalcula o
valor total do pedido pelo custo cadastrado em Produto_Fornecedor */
create trigger tr_item_pedido_insere
on PedidoDeProduto_Produto
after insert
as
begin
if exists (select *
from inserted i inner join PedidoDeProduto ped
on ped.cod_pedido = i.cod_pedido
where not exists (select *
from Produto_Fornecedor prf
where prf.cod_produto = i.cod_produto
and prf.id_fornecedor = ped.id_fornecedor))
begin
print 'O fornecedor do pedido nao disponibiliza este produto. Item
cancelado.'
rollback transaction
return
end
update PedidoDeProduto
set valorTotal = isnull((select sum(pp.quantidade * isnull(prf.custo_produto,
0))
from PedidoDeProduto_Produto pp inner join
Produto_Fornecedor prf
on prf.cod_produto = pp.cod_produto
where pp.cod_pedido = PedidoDeProduto.cod_pedido
and prf.id_fornecedor =
PedidoDeProduto.id_fornecedor), 0)
where cod_pedido in (select cod_pedido from inserted)
end
go
/* 4) Ao comprar, atualiza o estoque: quando a data de entrega de um
pedido passa de nula para preenchida, as quantidades do pedido
entram no estoque. DELETED traz a linha antes da alteracao e
INSERTED traz a linha depois da alteracao */
create trigger tr_pedido_entrega
on PedidoDeProduto
after update
as
begin
update Produto
set qtd_estoque = isnull(qtd_estoque, 0) + (select sum(pp.quantidade)
from PedidoDeProduto_Produto pp
inner join inserted i
on i.cod_pedido = pp.cod_pedido
inner join deleted d
on d.cod_pedido = i.cod_pedido
where pp.cod_produto =
Produto.cod_produto
and d.data_entrega is null
and i.data_entrega is not null)
where cod_produto in (select pp.cod_produto
from PedidoDeProduto_Produto pp
inner join inserted i
on i.cod_pedido = pp.cod_pedido
inner join deleted d
on d.cod_pedido = i.cod_pedido
where d.data_entrega is null
and i.data_entrega is not null)
end
go
/* 5) A soma das faturas de um pedido nao pode passar do valor
total do pedido */
create trigger tr_fatura_insere
on Fatura
after insert
as
begin
if exists (select *
from PedidoDeProduto ped
where ped.cod_pedido in (select cod_pedido from inserted)
and (select sum(fat.valor_fat)
from Fatura fat
where fat.cod_pedido = ped.cod_pedido) > ped.valorTotal)
begin
print 'A soma das faturas ultrapassa o valor total do pedido. Fatura
cancelada.'
rollback transaction
return
end
end
go
/* 6) Ao remover um cliente, remove tambem Pessoa_Fisica e Pessoa,
a nao ser que a pessoa continue cadastrada como funcionario
(sobreposicao da generalizacao de Pessoa Fisica) */
create trigger tr_cliente_remove
on Cliente
after delete
as
begin
delete from Pessoa_Fisica
where id_pessoa in (select id_pessoa from deleted)
and id_pessoa not in (select id_pessoa from Funcionario)
delete from Pessoa
where id_pessoa in (select id_pessoa from deleted)
and id_pessoa not in (select id_pessoa from Pessoa_Fisica)
end
go
/* 7) Ao remover um funcionario, remove tambem Pessoa_Fisica e Pessoa,
a nao ser que a pessoa continue cadastrada como cliente */
create trigger tr_funcionario_remove
on Funcionario
after delete
as
begin
delete from Pessoa_Fisica
where id_pessoa in (select id_pessoa from deleted)
and id_pessoa not in (select id_pessoa from Cliente)
delete from Pessoa
where id_pessoa in (select id_pessoa from deleted)
and id_pessoa not in (select id_pessoa from Pessoa_Fisica)
end
go
/* 8) Ao remover um fornecedor, remove tambem a Pessoa correspondente */
create trigger tr_fornecedor_remove
on Fornecedor
after delete
as
begin
delete from Pessoa
where id_pessoa in (select id_pessoa from deleted)
end
go
