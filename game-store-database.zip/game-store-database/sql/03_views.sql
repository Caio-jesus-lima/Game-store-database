-- Fonte: Entrega final do Projeto - Sistema de Gestao de Loja de Games (novembro de 2026).
-- Transcricao organizada do PDF final; requer validacao no Microsoft SQL Server.

use Loja_Games
go
/* 1) Exibe código, nome, preço, quantidade e tipo do produto, se ele for console
exibe também marca, modelo e cor, e se for jogo mostra plataforma, genero e
desenvolvedora, de todos os produtos */
create view visaoprodutoestoque
as
select p.cod_produto, p.nome, p.preco, p.qtd_estoque, p.tipo,
c.marca, c.modelo, c.cor,
j.plataforma_compativel, j.genero, j.desenvolvedora
from Produto p left outer join Console c
on c.cod_produto = p.cod_produto
left outer join Jogo j
on j.cod_produto = p.cod_produto
go
select * from visaoprodutoestoque
go
/* 2) Fornecedores que disponibilizam cada produto, e a que custo */
create view visaoprodutofornecedor
as
select p.cod_produto, p.nome nome_produto, prf.custo_produto,
f.id_pessoa id_fornecedor, f.razao_social, f.CNPJ
from Produto_Fornecedor prf inner join Produto p
on p.cod_produto = prf.cod_produto
inner join Fornecedor f
on f.id_pessoa = prf.id_fornecedor
go
select * from visaoprodutofornecedor
go
/* 3) Dados de cada venda: cliente, funcionario que atendeu,
data, valor e forma de pagamento (foco em funcionario) */
create view visaovenda
as
select v.cod_venda, pfcli.nome nome_cliente, pfcli.CPF cpf_cliente,
pffunc.nome nome_funcionario, func.cadastro_func,
v.data_venda, v.valorTotal, v.forma_pagamento
from Venda v inner join Cliente cli
on cli.id_pessoa = v.id_cliente
inner join Pessoa_Fisica pfcli
on pfcli.id_pessoa = cli.id_pessoa
inner join Funcionario func
on func.id_pessoa = v.id_funcionario
inner join Pessoa_Fisica pffunc
on pffunc.id_pessoa = func.id_pessoa
go
select * from visaovenda
go
/* 4) Produtos de cada venda, com valor unitario e total do item (foco nas vendas) */
create view visaoitemvenda
as
select vp.cod_venda, p.cod_produto, p.nome nome_produto,
vp.quantidade, p.preco valor_unitario,
(vp.quantidade * p.preco) valor_total_item
from Venda_Produto vp inner join Produto p
on p.cod_produto = vp.cod_produto
go
select * from visaoitemvenda
go
/* 5) Produtos e as vendas em que aparecem.
A juncao exterior traz o produto mesmo sem venda associada,
e nesse caso o codigo da venda vem nulo. Serve de base para
consultar, por exemplo, os produtos que nunca foram vendidos */
create view visaoprodutovenda
as
select p.cod_produto, p.nome, p.preco, p.qtd_estoque, vp.cod_venda
from Produto p left outer join Venda_Produto vp
on vp.cod_produto = p.cod_produto
go
select * from visaoprodutovenda
where cod_venda is null
go
/* 6) Historico de compras de cada cliente */
create view visaogastocliente
as
select c.id_pessoa id_cliente, pf.nome, pf.CPF,
count(v.cod_venda) qtd_compras,
sum(v.valorTotal) total_gasto
from Cliente c inner join Pessoa_Fisica pf
on pf.id_pessoa = c.id_pessoa
inner join Venda v
on v.id_cliente = c.id_pessoa
group by c.id_pessoa, pf.nome, pf.CPF
go
select * from visaogastocliente
go
/* 7) Vendas com o nome do cliente. Serve de base para consultar,
por exemplo, as vendas cujo valor supera a media geral.
A subconsulta calcula a media e devolve um unico valor */
create view visaovendacliente
as
select v.cod_venda, v.data_venda, v.valorTotal, pf.nome nome_cliente
from Venda v inner join Cliente c
on c.id_pessoa = v.id_cliente
inner join Pessoa_Fisica pf
on pf.id_pessoa = c.id_pessoa
go
select * from visaovendacliente
where valorTotal > (select avg(valorTotal) from Venda)
go
/* 8) Itens solicitados em cada pedido de reposicao de estoque */
create view visaoitempedido
as
select ped.cod_pedido, ped.data_pedido, ped.data_entrega,
f.razao_social, p.cod_produto, p.nome nome_produto,
pp.quantidade
from PedidoDeProduto ped inner join Fornecedor f
on f.id_pessoa = ped.id_fornecedor
inner join PedidoDeProduto_Produto pp
on pp.cod_pedido = ped.cod_pedido
inner join Produto p
on p.cod_produto = pp.cod_produto
go
select * from visaoitempedido
go
/* 9) Faturas dos pedidos de reposicao. Serve de base para
consultar, por exemplo, as faturas ainda nao pagas */
create view visaofatura
as
select ped.cod_pedido, f.razao_social, fat.num_fatura,
fat.valor_fat, fat.data_venc, fat.data_pag
from Fatura fat inner join PedidoDeProduto ped
on ped.cod_pedido = fat.cod_pedido
inner join Fornecedor f
on f.id_pessoa = ped.id_fornecedor
go
select * from visaofatura
where data_pag is null
go
/* 10) Pessoas cadastradas ao mesmo tempo como cliente e como
funcionario, situacao permitida pela sobreposicao da
generalizacao de Pessoa Fisica */
create view visaoclientefuncionario
as
select pf.id_pessoa, pf.CPF, pf.nome, func.cadastro_func
from Cliente cli inner join Funcionario func
on func.id_pessoa = cli.id_pessoa
inner join Pessoa_Fisica pf
on pf.id_pessoa = cli.id_pessoa
go
select * from visaoclientefuncionario
go
