-- Fonte: Entrega final do Projeto - Sistema de Gestao de Loja de Games (novembro de 2026).
-- Transcricao organizada do PDF final; requer validacao no Microsoft SQL Server.

use Loja_Games
go
/* 1) Cadastra um cliente: INSERT em Pessoa, Pessoa_Fisica e Cliente.
Se o CPF ja existe em Pessoa_Fisica (por exemplo, a pessoa ja e
funcionario), aproveita o mesmo id_pessoa, situacao permitida pela
sobreposicao da generalizacao de Pessoa Fisica */
create procedure proc_cadastra_cliente
@cpf CHAR(11),
@nome VARCHAR(150),
@telefone CHAR(11),
@email VARCHAR(100),
@id_pessoa INT OUTPUT,
@erro CHAR(1) OUTPUT
as
begin
begin try
begin transaction
set @id_pessoa = (select id_pessoa from Pessoa_Fisica where CPF = @cpf)
if @id_pessoa is null
begin
set @id_pessoa = (select isnull(max(id_pessoa), 0) + 1 from
Pessoa)
insert into Pessoa (id_pessoa, telefone, email, tipo)
values (@id_pessoa, @telefone, @email, 1)
insert into Pessoa_Fisica (id_pessoa, CPF, nome)
values (@id_pessoa, @cpf, @nome)
end
insert into Cliente (id_pessoa)
values (@id_pessoa)
commit transaction
set @erro = '0'
end try
begin catch
if @@trancount > 0
rollback transaction
set @erro = '1'
print error_message()
end catch
end
go
/* 2) Cadastra um funcionario: INSERT em Pessoa, Pessoa_Fisica e
Funcionario, com a mesma regra de sobreposicao do procedimento 1 */
create procedure proc_cadastra_funcionario
@cpf CHAR(11),
@nome VARCHAR(150),
@telefone CHAR(11),
@email VARCHAR(100),
@cadastro_func INT,
@salario NUMERIC(10,2),
@id_pessoa INT OUTPUT,
@erro CHAR(1) OUTPUT
as
begin
begin try
begin transaction
set @id_pessoa = (select id_pessoa from Pessoa_Fisica where CPF = @cpf)
if @id_pessoa is null
begin
set @id_pessoa = (select isnull(max(id_pessoa), 0) + 1 from
Pessoa)
insert into Pessoa (id_pessoa, telefone, email, tipo)
values (@id_pessoa, @telefone, @email, 1)
insert into Pessoa_Fisica (id_pessoa, CPF, nome)
values (@id_pessoa, @cpf, @nome)
end
insert into Funcionario (id_pessoa, cadastro_func, salario)
values (@id_pessoa, @cadastro_func, @salario)
commit transaction
set @erro = '0'
end try
begin catch
if @@trancount > 0
rollback transaction
set @erro = '1'
print error_message()
end catch
end
go
/* 3) Cadastra um fornecedor: INSERT em Pessoa e Fornecedor */
create procedure proc_cadastra_fornecedor
@cnpj CHAR(14),
@razao_social VARCHAR(150),
@telefone CHAR(11),
@email VARCHAR(100),
@id_pessoa INT OUTPUT,
@erro CHAR(1) OUTPUT
as
begin
begin try
begin transaction
set @id_pessoa = (select isnull(max(id_pessoa), 0) + 1 from Pessoa)
insert into Pessoa (id_pessoa, telefone, email, tipo)
values (@id_pessoa, @telefone, @email, 2)
insert into Fornecedor (id_pessoa, CNPJ, razao_social)
values (@id_pessoa, @cnpj, @razao_social)
commit transaction
set @erro = '0'
end try
begin catch
if @@trancount > 0
rollback transaction
set @erro = '1'
print error_message()
end catch
end
go
/* 4) Atualiza telefone e e-mail de qualquer pessoa cadastrada
(cliente, funcionario ou fornecedor) */
create procedure proc_atualiza_contato
@id_pessoa INT,
@telefone CHAR(11),
@email VARCHAR(100),
@erro CHAR(1) OUTPUT
as
begin
update Pessoa
set telefone = @telefone, email = @email
where id_pessoa = @id_pessoa
if @@rowcount = 0
begin
set @erro = '1'
print 'Pessoa nao encontrada'
end
else
set @erro = '0'
end
go
/* 5) Registra uma venda (cabecalho). O valor total comeca em zero e
e calculado pelo gatilho tr_item_venda_insere a cada item incluido */
create procedure proc_registra_venda
@id_cliente INT,
@id_funcionario INT,
@data_venda DATE,
@forma_pagamento CHAR(20),
@cod_venda INT OUTPUT,
@erro CHAR(1) OUTPUT
as
begin
begin try
set @cod_venda = (select isnull(max(cod_venda), 0) + 1 from Venda)
insert into Venda (cod_venda, id_cliente, id_funcionario, data_venda,
valorTotal, forma_pagamento)
values (@cod_venda, @id_cliente, @id_funcionario, @data_venda, 0,
@forma_pagamento)
set @erro = '0'
end try
begin catch
set @cod_venda = null
set @erro = '1'
print error_message()
end catch
end
go
/* 6) Inclui um produto em uma venda. Confere o estoque antes do INSERT;
a baixa do estoque e o novo valor total ficam com o gatilho
tr_item_venda_insere */
create procedure proc_adiciona_item_venda
@cod_venda INT,
@cod_produto INT,
@quantidade INT,
@erro CHAR(1) OUTPUT
as
begin
if @quantidade <= 0
begin
set @erro = '1'
print 'Quantidade invalida'
end
else if (select isnull(qtd_estoque, 0) from Produto where cod_produto =
@cod_produto) < @quantidade
begin
set @erro = '1'
print 'Estoque insuficiente'
end
else
begin
begin try
insert into Venda_Produto (cod_venda, cod_produto, quantidade)
values (@cod_venda, @cod_produto, @quantidade)
set @erro = '0'
end try
begin catch
set @erro = '1'
print error_message()
end catch
end
end
go
/* 7) Cancela uma venda: remove os itens e depois a venda.
O gatilho tr_item_venda_remove devolve os produtos ao estoque */
create procedure proc_cancela_venda
@cod_venda INT,
@erro CHAR(1) OUTPUT
as
begin
if not exists (select * from Venda where cod_venda = @cod_venda)
begin
set @erro = '1'
print 'Venda nao encontrada'
end
else
begin
begin try
begin transaction
delete from Venda_Produto where cod_venda = @cod_venda
delete from Venda where cod_venda = @cod_venda
commit transaction
set @erro = '0'
end try
begin catch
if @@trancount > 0
rollback transaction
set @erro = '1'
print error_message()
end catch
end
end
go
/* 8) Registra um pedido de reposicao de estoque para um unico
fornecedor. O valor total comeca em zero e e calculado pelo gatilho
tr_item_pedido_insere; a data de entrega fica nula ate a entrega */
create procedure proc_registra_pedido
@id_fornecedor INT,
@data_pedido DATE,
@cod_pedido INT OUTPUT,
@erro CHAR(1) OUTPUT
as
begin
begin try
set @cod_pedido = (select isnull(max(cod_pedido), 0) + 1 from
PedidoDeProduto)
insert into PedidoDeProduto (cod_pedido, data_pedido, valorTotal,
data_entrega, id_fornecedor)
values (@cod_pedido, @data_pedido, 0, null, @id_fornecedor)
set @erro = '0'
end try
begin catch
set @cod_pedido = null
set @erro = '1'
print error_message()
end catch
end
go
/* 9) Inclui um produto em um pedido de reposicao. Nao aceita itens
em pedido ja entregue ou ja faturado */
create procedure proc_adiciona_item_pedido
@cod_pedido INT,
@cod_produto INT,
@quantidade INT,
@erro CHAR(1) OUTPUT
as
begin
if @quantidade <= 0
begin
set @erro = '1'
print 'Quantidade invalida'
end
else if exists (select * from PedidoDeProduto where cod_pedido = @cod_pedido
and data_entrega is not null)
begin
set @erro = '1'
print 'Pedido ja entregue'
end
else if exists (select * from Fatura where cod_pedido = @cod_pedido)
begin
set @erro = '1'
print 'Pedido ja faturado'
end
else
begin
begin try
insert into PedidoDeProduto_Produto (cod_pedido, cod_produto,
quantidade)
values (@cod_pedido, @cod_produto, @quantidade)
set @erro = '0'
end try
begin catch
set @erro = '1'
print error_message()
end catch
end
end
go
/* 10) Registra a entrega de um pedido. O gatilho tr_pedido_entrega
soma as quantidades do pedido ao estoque */
create procedure proc_registra_entrega
@cod_pedido INT,
@data_entrega DATE,
@erro CHAR(1) OUTPUT
as
begin
update PedidoDeProduto
set data_entrega = @data_entrega
where cod_pedido = @cod_pedido and data_entrega is null
if @@rowcount = 0
begin
set @erro = '1'
print 'Pedido nao encontrado ou ja entregue'
end
else
set @erro = '0'
end
go
/* 11) Parcela o pagamento de um pedido em faturas mensais.
A ultima parcela recebe a diferenca do arredondamento, para que a
soma das faturas seja igual ao valor total do pedido */
create procedure proc_gera_faturas
@cod_pedido INT,
@qtd_parcelas INT,
@primeiro_venc DATE,
@erro CHAR(1) OUTPUT
as
begin
declare @valor_total NUMERIC(10,2)
declare @valor_parcela NUMERIC(10,2)
declare @num INT
set @valor_total = (select valorTotal from PedidoDeProduto where cod_pedido =
@cod_pedido)
if @valor_total is null or @valor_total = 0 or @qtd_parcelas < 1
begin
set @erro = '1'
print 'Pedido nao encontrado, sem itens ou numero de parcelas invalido'
end
else if exists (select * from Fatura where cod_pedido = @cod_pedido)
begin
set @erro = '1'
print 'Pedido ja possui faturas'
end
else
begin
begin try
begin transaction
set @valor_parcela = @valor_total / @qtd_parcelas
set @num = 1
while @num <= @qtd_parcelas
begin
if @num = @qtd_parcelas
set @valor_parcela = @valor_total - (@valor_parcela
* (@qtd_parcelas - 1))
insert into Fatura (num_fatura, cod_pedido, valor_fat,
data_venc, data_pag)
values (@num, @cod_pedido, @valor_parcela, dateadd(month,
@num - 1, @primeiro_venc), null)
set @num = @num + 1
end
commit transaction
set @erro = '0'
end try
begin catch
if @@trancount > 0
rollback transaction
set @erro = '1'
print error_message()
end catch
end
end
go
/* 12) Registra o pagamento de uma fatura ainda nao paga */
create procedure proc_paga_fatura
@num_fatura INT,
@cod_pedido INT,
@data_pag DATE,
@erro CHAR(1) OUTPUT
as
begin
update Fatura
set data_pag = @data_pag
where num_fatura = @num_fatura and cod_pedido = @cod_pedido and data_pag is
null
if @@rowcount = 0
begin
set @erro = '1'
print 'Fatura nao encontrada ou ja paga'
end
else
set @erro = '0'
end
go
/* Os procedimentos 13 a 17 sao consultas: cada um aplica um WHERE
sobre uma visao ja criada, que serve de base para elas */
/* 13) Disponibilidade de produtos em estoque, buscando por parte do nome.
O parametro e VARCHAR para nao levar espacos em branco para o LIKE */
create procedure proc_consulta_produto
@nome VARCHAR(60)
as
begin
select *
from visaoprodutoestoque
where nome like '%' + @nome + '%'
end
go
/* 14) Historico de compras de um cliente, pelo CPF */
create procedure proc_historico_cliente
@cpf CHAR(11)
as
begin
select *
from visaovenda
where cpf_cliente = @cpf
end
go
/* 15) Vendas processadas por um funcionario, pelo cadastro funcional */
create procedure proc_vendas_funcionario
@cadastro_func INT
as
begin
select *
from visaovenda
where cadastro_func = @cadastro_func
end
go
/* 16) Fornecedores que abastecem um produto e a que custo,
do menor para o maior custo */
create procedure proc_fornecedores_produto
@cod_produto INT
as
begin
select *
from visaoprodutofornecedor
where cod_produto = @cod_produto
order by custo_produto
end
go
/* 17) Faturas de um pedido de reposicao, pagas e pendentes */
create procedure proc_faturas_pedido
@cod_pedido INT
as
begin
select *
from visaofatura
where cod_pedido = @cod_pedido
end
go
