-- Fonte: Entrega final do Projeto - Sistema de Gestao de Loja de Games (novembro de 2026).
-- Transcricao organizada do PDF final; requer validacao no Microsoft SQL Server.

create database Loja_Games
go
use Loja_Games
go
create table Pessoa(
id_pessoa INT not null primary key,
telefone CHAR(11) null,
email VARCHAR(100) null,
tipo TINYINT not null
)
go
create table Pessoa_Fisica(
id_pessoa INT not null primary key references Pessoa(id_pessoa),
CPF CHAR(11) not null unique,
nome VARCHAR(150) not null
)
go
create table Fornecedor(
id_pessoa INT not null primary key references Pessoa(id_pessoa),
CNPJ CHAR(14) not null unique,
razao_social VARCHAR(150) not null
)
go
create table Cliente(
id_pessoa INT not null primary key references Pessoa_Fisica(id_pessoa)
)
go
create table Funcionario(
id_pessoa INT not null primary key references Pessoa_Fisica(id_pessoa),
cadastro_func INT not null unique,
salario NUMERIC(10,2) null
)
go
create table Produto(
cod_produto INT not null primary key,
nome CHAR(60) not null,
descricao VARCHAR(250) null,
preco NUMERIC(10,2) not null,
qtd_estoque INT null,
tipo TINYINT null
)
go
create table Console(
cod_produto INT not null primary key references Produto(cod_produto),
marca CHAR(20) null,
modelo VARCHAR(100) null,
cor CHAR(20) null
)
go
create table Jogo(
cod_produto INT not null primary key references Produto(cod_produto),
plataforma_compativel CHAR(30) null,
genero CHAR(20) null,
classificacao_etaria CHAR(2) null,
desenvolvedora VARCHAR(100) null
)
go
create table PedidoDeProduto(
cod_pedido INT not null primary key,
data_pedido DATE not null,
valorTotal NUMERIC(10,2) not null,
data_entrega DATE null,
id_fornecedor INT not null references Fornecedor(id_pessoa)
)
go
create table Fatura(
num_fatura INT not null,
cod_pedido INT not null references PedidoDeProduto(cod_pedido),
valor_fat NUMERIC(10,2) not null,
data_venc DATE not null,
data_pag DATE null,
primary key (num_fatura, cod_pedido)
)
go
create table Venda(
cod_venda INT not null primary key,
id_cliente INT not null references Cliente(id_pessoa),
id_funcionario INT not null references Funcionario(id_pessoa),
data_venda DATE not null,
valorTotal NUMERIC(10,2) not null,
forma_pagamento CHAR(20) null
)
go
create table Venda_Produto(
cod_venda INT not null references Venda(cod_venda),
cod_produto INT not null references Produto(cod_produto),
quantidade INT not null,
primary key (cod_venda, cod_produto)
)
go
create table PedidoDeProduto_Produto(
cod_pedido INT not null references PedidoDeProduto(cod_pedido),
cod_produto INT not null references Produto(cod_produto),
quantidade INT not null,
primary key (cod_pedido, cod_produto)
)
go
create table Produto_Fornecedor(
cod_produto INT not null references Produto(cod_produto),
id_fornecedor INT not null references Fornecedor(id_pessoa),
custo_produto NUMERIC(10,2) null,
primary key (cod_produto, id_fornecedor)
)
go
