-- Fonte: Entrega final do Projeto - Sistema de Gestao de Loja de Games (novembro de 2026).
-- Transcricao organizada do PDF final; requer validacao no Microsoft SQL Server.

USE Loja_Games
GO

create index ix_ped_forn
on PedidoDeProduto (id_fornecedor)
go
create index ix_fat_ped
on Fatura (cod_pedido)
go
create index ix_ven_cli
on Venda (id_cliente)
go
create index ix_ven_func
on Venda (id_funcionario)
go
create index ix_venpro_prod
on Venda_Produto (cod_produto)
go
create index ix_pedpro_prod
on PedidoDeProduto_Produto (cod_produto)
go
create index ix_profor_forn
on Produto_Fornecedor (id_fornecedor)
go
