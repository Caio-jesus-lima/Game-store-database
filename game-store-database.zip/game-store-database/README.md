# Game Store Database | Loja de Games

Academic database project developed collaboratively for **Banco de Dados II (ST767B)** at the **Faculty of Technology, University of Campinas (UNICAMP)**.

## Overview

A Microsoft SQL Server database for a physical video game store. It supports customer, employee, and supplier records; games and consoles; sales and inventory; replenishment orders; and supplier invoices.

## Database features

- Conceptual and relational data modeling
- Tables with primary keys, foreign keys, uniqueness constraints and indexes
- **10 views** for reporting and consultation
- **17 stored procedures** for data registration, updates, sales, replenishment, invoicing and queries
- **8 triggers** for inventory consistency, order rules and related-record cleanup

## Repository structure

```text
sql/
  01_schema.sql        Database and table definitions
  02_indexes.sql       Index definitions
  03_views.sql         SQL views
  04_procedures.sql    Stored procedures
  05_triggers.sql      Database triggers
docs/
  modelo-conceitual.png   Conceptual ER model (from the final report)
  projeto-final.pdf       Full final project report, in Portuguese
```

## Running the scripts

Open the scripts in **Microsoft SQL Server Management Studio (SSMS)** or another SQL Server client, then run them in numbered order on a test instance. The scripts use T-SQL and `GO` batch separators. The database name is `Loja_Games`.

**Important:** These SQL files were transcribed from the group's final PDF. They have **not** been executed or independently validated against SQL Server in this export. Review the code and test on a fresh database before using or publishing as a verified working solution. Avoid running `01_schema.sql` on an instance with an existing database of the same name.

## My contribution

As a member of the group, I was responsible for the **people registration and removal** workstream:

- Stored procedures 1–4: registering customers, employees and suppliers, and updating contact details
- Triggers 6–8: cleaning up related records when customers, employees or suppliers are removed
- Assigned test blocks 1 and 11 in the team's supporting document

## Team and credits

Collaborative project developed by **Caio de Jesus Lima, Guilherme Gali Rocha, Guilherme Soares da Silva, Henrique Carvalho de Mello and Maria Luisa Campos Falcão**.

This is a course project; contributions are shared and the repository does not claim sole authorship. The technical documentation was authored in Portuguese.
